# matrixmultiply

Matrix multiplication library with validation.

## Installation

```bash
pip install matrixmultiply
